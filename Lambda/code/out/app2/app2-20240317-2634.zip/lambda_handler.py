import boto3

def lambda_handler(event, context):
    return { "message" : "Hello World" }
