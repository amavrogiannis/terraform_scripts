def lambda_handler(event):
    return "Hello World"